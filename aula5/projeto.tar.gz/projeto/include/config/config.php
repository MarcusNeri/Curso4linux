<?php


//config.php
const HOST = 'localhost';
const USER = 'marcus';
const PORT = '5432';
const PASS = '123';
const DB = 'aula';

const BASEDIR = '500/aula5/projeto/';